package bean;

import BranchBuyMenu.TemplatePrice;
import BranchBuyMenu.TypeTicket;


public class BuyTicket {

    public static void entryBuyMenu ()  {

        System.out.println( "Bilet almaq ucun gosterilen emeliyyatlari icra edin. ");


        TypeTicket.type();
        TemplatePrice.template();










    }

}
